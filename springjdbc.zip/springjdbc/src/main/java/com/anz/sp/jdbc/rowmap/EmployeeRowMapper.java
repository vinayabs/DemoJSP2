package com.anz.sp.jdbc.rowmap;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.anz.sp.jdbc.entity.Employee;

public class EmployeeRowMapper implements RowMapper<Employee>{

	public Employee mapRow(ResultSet rs,int rowCount) throws SQLException
	{
		Employee emp = new Employee();
		emp.setEmpid(rs.getInt(1));
		emp.setEname(rs.getString(2));
		emp.setSalary(rs.getDouble(3));
		return emp;
	}
}
