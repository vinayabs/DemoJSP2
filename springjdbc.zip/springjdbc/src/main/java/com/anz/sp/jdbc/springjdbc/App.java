package com.anz.sp.jdbc.springjdbc;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.anz.sp.jdbc.entity.Employee;
import com.anz.sp.jdbc.config.AppConfig;
import com.anz.sp.jdbc.dao.EmployeeDAO;
import java.util.List;

public class App 
{
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		EmployeeDAO edao = context.getBean("employeeDAO",EmployeeDAO.class);
		//Employee e = edao.getEmployee(100);
		List<Employee> elist = edao.getAllEmployees();
		for(Employee e : elist)
		System.out.println(e.getEmpid()+" "+e.getEname()+" "+e.getSalary());
		
		
		/*int noOfRows = edao.getEmployeesCount();
		System.out.println("Total Employees found "+noOfRows);
		String ename = edao.getEmployeeName(100);
		System.out.println();*/
		
		
		
		/*if(edao.insertEmployee(e))
	     
		System.out.println("Employee record inserted");
		else
		System.out.println("Record cannot be inserted");*/
		/*if(edao.modifyEmployee(new Employee(100,"New Name",1111)))
		     
			System.out.println("Employee record modified");
			else
			System.out.println("Record cannot be modified");*/
		/*if(edao.deleteEmployee(100))
			System.out.println("Employee 100 Deleted");
		else
			System.out.println("Employee cannot be Deleted");*/
    }
}
