package com.anz.sp.jdbc.dao;
import java.util.List;
import java.sql.*;
import org.springframework.jdbc.core.JdbcTemplate;
import com.anz.sp.jdbc.entity.Employee;
import com.anz.sp.jdbc.rowmap.EmployeeRowMapper;


public class EmployeeDAO 
{
	JdbcTemplate jdbcTemplate;

	public EmployeeDAO() {

	}
	public Employee getEmployee(int empid)
	{
		String qry="select * from employee where empid=?";
		Employee e = jdbcTemplate.queryForObject(qry, new EmployeeRowMapper(),empid);
		return e;
	}

	public EmployeeDAO(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate=jdbcTemplate;
	}
	
	public List<Employee> getAllEmployees()
	{
		String qry = "Select * from employee";
		return jdbcTemplate.query(qry, new EmployeeRowMapper());
	}
	
	public int getEmployeesCount()
	{
		String qry ="select count(*) from employee";
		int count = jdbcTemplate.queryForObject(qry,Integer.class);
		return count;				
	}

	public String getEmployeeName(int empid)
	{
		String qry="select ename from employee where empid=?";
		String ename=jdbcTemplate.queryForObject(qry,String.class,empid);
		return ename;

	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate=jdbcTemplate;	
	}
	public boolean insertEmployee(Employee emp)
	{
		String qry = "insert into employee values(?,?,?)";
		int count = jdbcTemplate.update
				(qry,emp.getEmpid(),emp.getEname(),emp.getSalary());
		return count ==1;
	}
	public boolean deleteEmployee(int empid)
	{
		String qry = "delete from employee where empid=?";
		int count = jdbcTemplate.update(qry,empid);
		return count ==1;
	}
	public boolean modifyEmployee(Employee emp)
	{
		String qry = "update employee set ename=?,salary=? where empid=?";
		int count = jdbcTemplate.update(qry,emp.getEname(),emp.getSalary(),emp.getEmpid());
		return count==1;
	}
}
