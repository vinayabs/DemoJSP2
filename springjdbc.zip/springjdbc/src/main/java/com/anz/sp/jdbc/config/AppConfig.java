package com.anz.sp.jdbc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.anz.sp.jdbc.dao.EmployeeDAO;
@Configuration
public class AppConfig {
    @Bean()
    public DriverManagerDataSource driverManagerDataSource()
    {
    	DriverManagerDataSource dmds = new DriverManagerDataSource();
    	dmds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
    	dmds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
    	dmds.setUsername("hr");
    	dmds.setPassword("hr");
    	return dmds;
    }
    @Bean("jdbcTemplate")
    public JdbcTemplate jdbcTemplate()
    {
    	JdbcTemplate jtemplate = new JdbcTemplate();
    	jtemplate.setDataSource(driverManagerDataSource());
    	return jtemplate;
    }
    @Bean("employeeDAO")
    public EmployeeDAO employeeDAO()
    {
    	return new EmployeeDAO(jdbcTemplate());
    }
}

