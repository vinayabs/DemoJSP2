package com.anz.di.maven.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import com.anz.di.maven.bean.Employee;

public class EmployeeDAO {

	/*DataSource dataSource;
	
	public EmployeeDAO(DataSource dataSource) {
		this.dataSource=dataSource;
	}
	public Employee getEmployee(int empid) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		Employee emp = null;
		try {
			con = dataSource.getConnection();
			pst = con.prepareStatement("select * from employee where empid=?");
			pst.setInt(1, empid);
			rs = pst.executeQuery();
			if(rs.next())
				emp = new Employee(rs.getInt(1), rs.getString(2), rs.getDouble(3));
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return emp;
		
	}
	*/
}
