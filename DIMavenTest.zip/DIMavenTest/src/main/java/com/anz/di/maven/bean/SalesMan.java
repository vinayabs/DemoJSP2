package com.anz.di.maven.bean;

public class SalesMan extends Employee{
	double incentives;
	
	public SalesMan() 
	{
		//super(int empid, String ename, double salary);
	}

	public SalesMan(double incentives) {
		
		System.out.println("SM Obj created");
		this.incentives = incentives;
	}

	public int getEmpid() {
		return empid;
	}

	public double getIncentives() {
		return incentives;
	}

	public void setIncentives(double incentives) {
		this.incentives = incentives;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
