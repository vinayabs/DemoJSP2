package com.anz.di.maven.bean;
import java.util.*;
public class Company {
	String cname;
	String location;
	Map<Integer,String> departments;
	public Company() {}
	public Company(String cname, String location, Map<Integer,String> departments) {
		this.cname = cname;
		this.location = location;
		this.departments = departments;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Map<Integer,String> getDepartments() {
		return departments;
	}
	public void setDepartments(Map<Integer,String> departments) {
		this.departments = departments;
	}
	
 
}
 