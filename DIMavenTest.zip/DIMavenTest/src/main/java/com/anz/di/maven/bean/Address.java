package com.anz.di.maven.bean;

public class Address {
	String hno;
	String streetName;
	String city;
	public Address() {}
	public Address(String hno, String streetName, String city) {
		this.hno = hno;
		this.streetName = streetName;
		this.city = city;
	}
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
