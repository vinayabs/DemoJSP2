package com.anz.di.maven.bean;

public class Employee {
	int empid;
	String ename;
	double salary;
	Address address;
	public Employee() {}
	public Employee(int empid,String ename,double salary)
	{
		//System.out.println("Employee Obj created");
		this.empid=empid;
		this.ename=ename;
		this.salary=salary;

	}
	public Employee(int empid,String ename,double salary,Address address)
	{
		//System.out.println("Employee Obj created");
		this.empid=empid;
		this.ename=ename;
		this.salary=salary;
		this.address=address;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}


}
