package com.anz.di.maven.DIMavenTest;
import java.util.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Map.Entry;

import com.anz.di.maven.bean.Address;
import com.anz.di.maven.bean.Company;
import com.anz.di.maven.bean.Employee;


public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
        Employee e = ctx.getBean("empBean1",Employee.class);
        System.out.println(e.getEmpid()+" "+e.getEname()+" "+e.getSalary());
        Address a = e.getAddress();
        System.out.println(a.getHno()+" "+a.getCity()+" "+a.getStreetName());
        ctx.close();
    }

	
}
