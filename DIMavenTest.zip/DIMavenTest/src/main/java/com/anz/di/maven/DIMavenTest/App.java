package com.anz.di.maven.DIMavenTest;
import java.util.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Map.Entry;
import com.anz.di.maven.bean.Company;


public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
        
        Company c = ctx.getBean("cmp1",Company.class);
        System.out.println(c.getCname()+" "+c.getLocation());
        Map<Integer,String> dpts = c.getDepartments();
        System.out.println(dpts.getClass().getName());
        for(Entry<Integer,String> d: dpts.entrySet())
        	System.out.println(d.getKey()+" "+d.getValue());
        ctx.close();
    }

	
}
